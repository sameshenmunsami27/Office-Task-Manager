from manager import TaskManager


def main():
    manager = TaskManager()

    while True:
        print("\n--- OFFICE TASK MANAGER ---")
        print(
            "1. View Schedule\n2. Log New Task\n3. Update Task\n4. Remove Task\n5. Save"
            "\n6. Exit"
        )
        choice = input("\nSelect Option: ")

        if choice == "1":
            [print(f"TITLE: {t.title} | DESC: {t.description}") for t in manager.tasks]
        elif choice == "2":
            manager.create_task(input("Title: "), input("Description: "))
        elif choice == "3":
            t = input("Task Title to Update: ")
            d = input("New Description: ")
            print("Updated." if manager.update_task(t, d) else "Not found.")
        elif choice == "4":
            print(
                "Deleted."
                if manager.delete_task(input("Title to Remove: "))
                else "Not found."
            )
        elif choice == "5":
            manager.save_tasks()
            print("Office records saved to file.")
        elif choice == "6":
            break


if __name__ == "__main__":
    main()
