class Task:
    """The Blueprint for a single Office Task."""

    def __init__(self, title, description):
        # We only use Title and Description for the office app
        self.title = title
        self.description = description

    def to_string(self):
        """Converts the object to a suitable format for tasks.txt."""
        return f"{self.title}|{self.description}"
