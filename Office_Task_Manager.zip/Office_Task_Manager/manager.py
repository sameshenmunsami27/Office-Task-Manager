import os
from task_model import Task


class TaskManager:
    """Handles CRUD logic and the file-based Data Access Layer."""

    def __init__(self, filename="tasks.txt"):
        self.filename = filename
        self.tasks = self.load_tasks()

    def load_tasks(self):
        """Reads tasks.txt and converts each line into a Task object."""
        if not os.path.exists(self.filename):
            return []
        try:
            with open(self.filename, "r") as file:
                lines = [line.strip().split("|") for line in file if "|" in line]
                return [Task(p[0], p[1]) for p in lines if len(p) == 2]
        except (IOError, IndexError):
            return []

    def save_tasks(self):
        """Writes the current list of tasks to tasks.txt."""
        try:
            with open(self.filename, "w") as file:
                file.writelines(f"{t.to_string()}\n" for t in self.tasks)
            print(f"Successfully saved to {self.filename}.")
        except IOError as e:
            print(f"Error saving: {e}")

    def create_task(self, title, description):
        """CRUD: Create - uses title as the key."""
        self.tasks.append(Task(title, description))

    def get_task_by_title(self, title):
        """CRUD: Read - finds task by title."""
        return next((t for t in self.tasks if t.title.lower() == title.lower()), None)

    def update_task(self, title, new_description):
        """UPDATE: Modifies the description of an existing task."""
        task = self.get_task_by_title(title)
        if task:
            task.description = new_description
            return True
        return False

    def delete_task(self, title):
        """CRUD: Delete - removes task by title."""
        initial_count = len(self.tasks)
        self.tasks = [t for t in self.tasks if t.title.lower() != title.lower()]
        return len(self.tasks) < initial_count
