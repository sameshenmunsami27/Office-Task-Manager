import unittest
from manager import TaskManager


class TestOfficeTaskManager(unittest.TestCase):

    def setUp(self):
        """Sets up a fresh TaskManager in memory before each test."""
        # We pass a dummy filename, but we won't call save/load
        self.manager = TaskManager(filename="test_only.txt")
        self.manager.tasks = []  # Ensure the list is empty for isolation

    def test_create_use_case(self):
        """Use Case 1: CREATE - Verifying tasks are correctly added to the list."""
        self.manager.create_task("Project Alpha", "Initial planning phase")
        self.assertEqual(len(self.manager.tasks), 1)
        self.assertEqual(self.manager.tasks[0].title, "Project Alpha")

    def test_read_use_case(self):
        """Use Case 2: READ - Verifying a task can be retrieved by its office title."""
        self.manager.create_task("Payroll", "Process month-end salaries")
        task = self.manager.get_task_by_title("Payroll")
        self.assertIsNotNone(task)
        self.assertEqual(task.description, "Process month-end salaries")

    def test_update_use_case(self):
        """Use Case 3: UPDATE - Verifying an existing office record can be modified."""
        self.manager.create_task("Staff Meeting", "Room 101")
        # Update logic
        success = self.manager.update_task("Staff Meeting", "Changed to Zoom")

        updated_task = self.manager.get_task_by_title("Staff Meeting")
        self.assertTrue(success)
        self.assertEqual(updated_task.description, "Changed to Zoom")

    def test_delete_use_case(self):
        """Use Case 4: DELETE - Verifying a task is successfully removed from
        records."""
        self.manager.create_task("Old Archive", "Throw away")
        # Delete logic
        success = self.manager.delete_task("Old Archive")
        self.assertTrue(success)
        self.assertEqual(len(self.manager.tasks), 0)


if __name__ == "__main__":
    unittest.main()
